/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bringo;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URI;
import java.net.URISyntaxException;
import java.sql.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.*;


/**
 *
 * @author alisonwang
 */
public class dispatcher extends HttpServlet {


    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    synchronized protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //analyze URL, and find corresponding handler
      
        String servletPath = request.getServletPath();
        String ID = request.getParameter("ID");
        String replyJSON;
        
        if(servletPath.equals("/welcomPage")){
            response.setStatus(200);
            // tell the client the type of the response
            response.setContentType("text/plain;charset=UTF-8");
            // reply to the client with JSON string
            PrintWriter out = response.getWriter();                
            out.println(servletPath);
        }
        
        
        else if (servletPath.equals("/getScenarioNameByID")){
            try {
                // get scenario names
                replyJSON = getScenarioNameByID(ID);
                
                // Things went well so set the HTTP response code to 200 OK
                response.setStatus(200);
                // tell the client the type of the response
                response.setContentType("text/plain;charset=UTF-8");
                // reply to the client with JSON string
                PrintWriter out = response.getWriter();
                out.println(replyJSON); 
                
            } catch (Exception ex) {
                
                //change to setStatus(xxx);===========================================<<<<<<<<<<<<<<<<<<<<<
                response.setStatus(500);
            }
        }
        else if (servletPath.equals("/getItemListByID")){
            // get item list
            try {
                //get item list
                replyJSON = getItemListByID(ID);
                // Things went well so set the HTTP response code to 200 OK
                response.setStatus(200);
                // tell the client the type of the response
                response.setContentType("text/plain;charset=UTF-8");
                // reply to the client with JSON string
                PrintWriter out = response.getWriter();
                out.println(replyJSON);
                
            } catch (Exception ex) {
                
                //change to setStatus(xxx);===========================================<<<<<<<<<<<<<<<<<<<<<
                response.setStatus(500);
            }
            
        }
        else if (servletPath.equals("/getItemNameByID")){
            // get item name
            try {
                //get item list
                replyJSON = getItemNameByID(ID);
                // Things went well so set the HTTP response code to 200 OK
                response.setStatus(200);
                // tell the client the type of the response
                response.setContentType("text/plain;charset=UTF-8");
                // reply to the client with JSON string
                PrintWriter out = response.getWriter();
                out.println(replyJSON);
                
            } catch (Exception ex) {
                
                //change to setStatus(xxx);===========================================<<<<<<<<<<<<<<<<<<<<<
                response.setStatus(500);
            }
        }
        else if (servletPath.equals("/getTravelCategoryNameByID")){
            // get travel category name
            try {
                //get item list
                replyJSON = getTravelCategoryNameByID(ID);
                // Things went well so set the HTTP response code to 200 OK
                response.setStatus(200);
                // tell the client the type of the response
                response.setContentType("text/plain;charset=UTF-8");
                // reply to the client with JSON string
                PrintWriter out = response.getWriter();
                out.println(replyJSON);
                
            } catch (Exception ex) {
                
                //change to setStatus(xxx);===========================================<<<<<<<<<<<<<<<<<<<<<
                response.setStatus(500);
            }
        }
        else if (servletPath.equals("/getTravelItemListByID")){
            // get travel item list
            try {
                //get item list
                replyJSON = getTravelItemListByID(ID);
                // Things went well so set the HTTP response code to 200 OK
                response.setStatus(200);
                // tell the client the type of the response
                response.setContentType("text/plain;charset=UTF-8");
                // reply to the client with JSON string
                PrintWriter out = response.getWriter();
                out.println(replyJSON);
                
            } catch (Exception ex) {
                
                //change to setStatus(xxx);===========================================<<<<<<<<<<<<<<<<<<<<<
                response.setStatus(500);
            }
        }
        
    }
    
    private String getScenarioNameByID(String ID) throws URISyntaxException, SQLException {
        String replyJSON = "{";
        Boolean first = true;
        //create connection to database
        Connection conn = makeConnection();
        
        Statement stmt = null;
        String sql;
        
        stmt = conn.createStatement();
        conn.setAutoCommit(true);
        
        if (ID.equals("all")){
            //get all the names
            sql = "SELECT * FROM SCENARIOLIST;";
        }
        else {
            int IDint = Integer.parseInt(ID);
            sql = "SELECT * FROM SCENARIOLIST WHERE scID = "+IDint+";";
        }
        ResultSet r = stmt.executeQuery(sql);
        
        while(r.next()){
            int id  = r.getInt("scID");
            String name = r.getString("scName");
            if(!first){
                replyJSON += ",";
            }
            replyJSON += "\""+id+"\":\""+name+"\"";
            first = false;
        }
        replyJSON += "}";
        
        //close connections
        r.close();
        
        
        stmt.close();
        
        conn.close();
        
        return replyJSON;
    }
    
    private String getItemListByID(String ID) throws URISyntaxException, SQLException {
        String replyJSON = "{";
        String prevName, name;
        prevName = "";
        Boolean first = true;
        //create connection to database
        Connection conn = makeConnection();
        
        Statement stmt = null;
        String sql;
        
        stmt = conn.createStatement();
        conn.setAutoCommit(true);
        
        if (ID.equals("all")){
            //get all the names
            sql = "SELECT * FROM ITEMLIST ORDER BY itemName;";
        }
        else {
            int IDint = Integer.parseInt(ID);
            sql = "SELECT * FROM ITEMLIST WHERE scID = "+IDint+";";
        }
        ResultSet r = stmt.executeQuery(sql);
        
        while(r.next()){
            int id  = r.getInt("itemID");
            name = r.getString("itemName");
            if(!name.equals(prevName)){
                if(!first){
                    replyJSON += ",";
                }
                replyJSON += "\""+id+"\":\""+name+"\"";
            }
            first = false;
            prevName = name;
        }
        replyJSON += "}";
        
        //close connections
        r.close();
        stmt.close();
        conn.close();
        
        return replyJSON;
    }
    
    private String getItemNameByID(String ID) throws URISyntaxException, SQLException {
        String replyJSON = "{";
        int IDint = Integer.parseInt(ID);
        //create connection to database
        Connection conn = makeConnection();
        
        Statement stmt = null;
        String sql;
        
        stmt = conn.createStatement();
        conn.setAutoCommit(true);
        ResultSet r;
        if (IDint < 100 ){
            //get all the names
            sql = "SELECT * FROM ITEMLIST WHERE itemID = "+IDint+";";
            r = stmt.executeQuery(sql);
            while(r.next()){
                int id  = r.getInt("itemID");
                String name = r.getString("itemName");
                
                replyJSON += "\""+id+"\":\""+name+"\"";
                
            }
        }
        else {
            
            sql = "SELECT * FROM TRAVELITEMLIST WHERE trItemID = "+IDint+";";
            r = stmt.executeQuery(sql);
            while(r.next()){
                int id  = r.getInt("trItemID");
                String name = r.getString("trItemName");
                
                replyJSON += "\""+id+"\":\""+name+"\"";
                
            }
        }
        
        replyJSON += "}";
        
        //close connections
        r.close();
        
        
        stmt.close();
        
        conn.close();
        
        return replyJSON;
    }
    
    private String getTravelCategoryNameByID(String ID) throws URISyntaxException, SQLException {
        String replyJSON = "{";
        Boolean first = true;
        //create connection to database
        Connection conn = makeConnection();
        
        Statement stmt = null;
        String sql;
        
        stmt = conn.createStatement();
        conn.setAutoCommit(true);
        
        if (ID.equals("all")){
            //get all the names
            sql = "SELECT * FROM CATEGORYLIST;";
        }
        else {
            int IDint = Integer.parseInt(ID);
            sql = "SELECT * FROM CATEGORYLIST WHERE catID = "+IDint+";";
        }
        ResultSet r = stmt.executeQuery(sql);
        
        while(r.next()){
            int id  = r.getInt("catID");
            String name = r.getString("catName");
            if(!first){
                replyJSON += ",";
            }
            replyJSON += "\""+id+"\":\""+name+"\"";
            first = false;
        }
        replyJSON += "}";
        
        //close connections
        r.close();
        
        
        stmt.close();
        
        conn.close();
        
        return replyJSON;
    }
    
    private String getTravelItemListByID(String ID) throws URISyntaxException, SQLException {
        String replyJSON = "{";
        String prevName, name;
        prevName = "";
        Boolean first = true;
        //create connection to database
        Connection conn = makeConnection();
        
        Statement stmt = null;
        String sql;
        
        stmt = conn.createStatement();
        conn.setAutoCommit(true);
        
        if (ID.equals("all")){
            //get all the names
            sql = "SELECT * FROM TRAVELITEMLIST ORDER BY trItemName;";
        }
        else {
            int IDint = Integer.parseInt(ID);
            sql = "SELECT * FROM TRAVELITEMLIST WHERE catID = "+IDint+";";
        }
        ResultSet r = stmt.executeQuery(sql);
        
        while(r.next()){
            int id  = r.getInt("trItemID");
            name = r.getString("trItemName");
            if(!name.equals(prevName)){
                if(!first){
                    replyJSON += ",";
                }
                replyJSON += "\""+id+"\":\""+name+"\"";
            }
            first = false;
            prevName = name;
        }
        replyJSON += "}";
        
        //close connections
        r.close();
        stmt.close();
        conn.close();
        
        return replyJSON;
    }
    

    private Connection makeConnection() throws URISyntaxException, SQLException{
        URI dbUri = new URI(System.getenv("DATABASE_URL"));
        String username = dbUri.getUserInfo().split(":")[0];
        String password = dbUri.getUserInfo().split(":")[1];
        String dbUrl = "jdbc:postgresql://" + dbUri.getHost() + ':' + dbUri.getPort() + dbUri.getPath();
        return DriverManager.getConnection(dbUrl, username, password);
    }
    
    
    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    synchronized protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //get the url path
        String servletPath = request.getServletPath();
        //get the buffered reader
        BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream()));
        
        String message = "";
        String username = "";
        String password = "";        
        String line;
        
        //read from client
        while((line = br.readLine()) != null){
            message = message + line;
        }

        //parse json string
        JSONObject obj;
        try {
            obj = new JSONObject(message);
            username = obj.getString("username");
            password = obj.getString("password");
            
        } catch (JSONException ex) {
            response.setStatus(401);
            PrintWriter out = response.getWriter();
            out.println(ex.getMessage());
        }
        
        //case: register
        if(servletPath.equals("/register")){
            
            try {
                //call register and check if registered successfully
                if (register(username, password)){
                    //registered successfully
                    response.setStatus(200);
                }
                else {
                    //registered unsuccessfully
                    response.setStatus(401);
                    PrintWriter out = response.getWriter();
                    out.println("username already exist");
                }
            } catch (URISyntaxException ex) {
                response.setStatus(401);
                PrintWriter out = response.getWriter();
                out.println(ex.getMessage());
            } catch (SQLException ex) {
                response.setStatus(401);
                PrintWriter out = response.getWriter();
                out.println(ex.getMessage());
            }
            
            
        }
        else if (servletPath.equals("/login")){
            
            //call login method
            try {
                //call register and check if registered successfully
                if (login(username, password)){
                    //registered successfully
                    response.setStatus(200);
                }
                else {
                    //registered unsuccessfully
                    response.setStatus(401);
                    PrintWriter out = response.getWriter();
                    out.println("login failed");
                }
            } catch (URISyntaxException ex) {
                response.setStatus(401);
                PrintWriter out = response.getWriter();
                out.println(ex.getMessage());
            } catch (SQLException ex) {
                response.setStatus(401);
                PrintWriter out = response.getWriter();
                out.println(ex.getMessage());
            }
           
        }
    }
    
    private boolean register( String username, String password) throws URISyntaxException, SQLException{
        
        Connection conn = makeConnection();
        Statement stmt = null;
        stmt = conn.createStatement();
        conn.setAutoCommit(true);
        
        String sql;
        int count = -1;
        boolean result = false;
        
        //if username already exist, then not successful
        sql = "SELECT count(*) FROM USERLIST WHERE username = '"+ username +"';";
        ResultSet r = stmt.executeQuery(sql);
        while(r.next()){
            count = r.getInt("count");
        }
        
        if (count == 0){
            //make update to datebase
            
            sql = "INSERT INTO USERLIST (username, password) "
                    + "VALUES ( '"+ username +"', '"+password+"' );";
            stmt.executeUpdate(sql);
            result = true;
        }
        //close connections
        r.close();
        
        
        stmt.close();
        
        conn.close();
        
        //return result
        return result;
    }
    
    private boolean login( String username, String password) throws URISyntaxException, SQLException{
        
        Connection conn = makeConnection();
        Statement stmt = null;
        stmt = conn.createStatement();
        conn.setAutoCommit(true);
        
        String sql;
        int count = -1;
        boolean result = false;
        String correctPass = "";
        
        //if username exists, then compare the password
        sql = "SELECT count(*) FROM USERLIST WHERE username = '"+ username +"';";
        ResultSet r = stmt.executeQuery(sql);
        
        while(r.next()){
            count = r.getInt("count");
        }
        if (count == 1){
            //make update to datebase
            
            sql = "SELECT * FROM USERLIST WHERE username = '"+ username +"';";
            r = stmt.executeQuery(sql);
            while(r.next()){
                correctPass = r.getString("password");
            }
            if(correctPass.equals(password)){
                result = true;
            }
            
        }
        
        //close connections
        r.close();
        
        
        stmt.close();
        
        conn.close();
        
        //return result
        return result;
    }


}
